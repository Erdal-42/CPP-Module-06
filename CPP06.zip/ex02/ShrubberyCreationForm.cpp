/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ShrubberyCreationForm.cpp                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ekocak@student.42.org.tr>                  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/02 10:26:55 by ekocak            #+#    #+#             */
/*   Updated: 2023/08/02 10:26:55 by ekocak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ShrubberyCreationForm.hpp"

ShrubberyCreationForm::ShrubberyCreationForm() 
    : AForm("Shrubbery Creation Form", ShrubberySignGrade, ShrubberyExecGrade), _target("Anonymous") 
{
#if DEBUG
	std::cout << "Default Construction: Shrubbery Creation Form. " << *this << std::endl;
#endif
}

ShrubberyCreationForm::ShrubberyCreationForm(std::string theTarget) 
    : AForm("Shrubbery Creation Form", ShrubberySignGrade, ShrubberyExecGrade), _target(theTarget) 
{
#if DEBUG
	std::cout << "Parametized Construction: Shrubbery Creation Form. " << *this << std::endl;
#endif
}

ShrubberyCreationForm::~ShrubberyCreationForm() 
{
#if DEBUG
	std::cout << "Destruction: Shrubbery Creation Form. " << *this << std::endl;
#endif
}

ShrubberyCreationForm::ShrubberyCreationForm(ShrubberyCreationForm const &other)
    : AForm(other), _target(other._target)
{
#if DEBUG
	std::cout << "Copy Construction: Shrubbery Creation Form. " << *this << std::endl;
#endif
}

ShrubberyCreationForm &ShrubberyCreationForm::operator=(ShrubberyCreationForm const &other)
{
    if (this == &other)
        return (*this);

    AForm::operator=(other);
    _target = other._target;
#if DEBUG
	std::cout << "Assignment: Shrubbery Creation Form. " << *this << std::endl;
#endif
    return (*this);
}

std::string	ShrubberyCreationForm::getTarget() const
{
	return (_target);
}


//Generate Form
void ShrubberyCreationForm::invokeFormExecution(void) const
{
    int fd;
    int i;

    fd = open((_target + "_shrubbery" + ".txt").c_str(), O_RDWR | O_CREAT | O_APPEND);
    i = 0;
    while (i < 26)
    {
        write(fd, "abcdefghijklmnopqrstuvwxyz", ++ i);
        write(fd,"\n", 1);
    }
	i = 0;
	while (i < 10)
	{
		write(fd, &"123456789"[i ++], 1);
		if (!(i%3))
			write(fd, "\n", 1);
	}
	close(fd);
#if DEBUG
	std::cout << "Executed: Shrubbery Creation Form in " << _target << std::endl;
#endif
}