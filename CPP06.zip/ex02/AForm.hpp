/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   AForm.hpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ekocak@student.42.org.tr>                  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/02 10:26:55 by ekocak            #+#    #+#             */
/*   Updated: 2023/08/02 10:26:55 by ekocak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef AForm_HPP
# define AForm_HPP

#include <iostream>
#include "Bureaucrat.hpp"
#define DEBUG_AForm 0

class Bureaucrat;

class AForm
{
	private:
		std::string			_name;
		bool				_signed;
		const int			_signGrade;
		const int			_execGrade;

	protected:
        virtual void    	invokeFormExecution() const = 0;

	public:
		// Constructors / destructor / '=' overload
		AForm();
		virtual ~AForm();
		AForm(std::string, int, int);
		AForm(AForm const &);
		AForm & operator=(AForm const &);

		// Getters
        std::string			getName() const;
        bool                getSigned() const;
        int                 getSignGrade() const;
        int                 getExecGrade() const;

		// Setters
		void				setSigned(const bool new_value);

		// Nested Exception classes:
		class Exception : public std::exception
		{
			public:
				virtual const char* what() const throw();
		};
        class GradeTooHighException : public AForm::Exception 
        {
            public:
                virtual const char  *what(void) const throw(); 
        };
        class GradeTooLowException : public AForm::Exception
        {
            public:
                virtual const char *what(void) const throw();
        };
        class UnsignedFormException : public AForm::Exception
        {
            public:
                virtual const char *what(void) const throw();
        };
        class AlreadySignedException : public AForm::Exception
        {
            public:
                virtual const char *what(void) const throw();
        };

		// Functions
		void	beSigned(Bureaucrat & ref);
        void	execute(Bureaucrat const & executor) const;
	};

// << overload
std::ostream & operator<<( std::ostream & o, AForm const & rhs);

#endif