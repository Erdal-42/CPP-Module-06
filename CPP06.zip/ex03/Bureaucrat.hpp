/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Bureaucrat.hpp                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ekocak@student.42.org.tr>                  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/05 01:32:55 by ekocak            #+#    #+#             */
/*   Updated: 2023/08/05 01:32:55 by ekocak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef BUREAUCRAT_HPP
# define BUREAUCRAT_HPP

# include <iostream>
# include "AForm.hpp"

#define DEBUG   0

class AForm;

class Bureaucrat
{
	public:
		// Constructors / Destructor / '=' Overload
		Bureaucrat();
		Bureaucrat(std::string, int);
		~Bureaucrat();
		Bureaucrat(const Bureaucrat &);
		Bureaucrat &operator=(const Bureaucrat &);

        static int const minGrade = 150;
        static int const maxGrade = 1; 

		// Increment / Decrement grade
        void        		incrementGrade(void);
        void        		incrementGrade(int);
		void        		decrementGrade(void);
        void        		decrementGrade(int);

		// Getters
        std::string 		getName(void) const;
        int         		getGrade(void) const;

		// Setters
		void				setGrade( const int new_grade);

		// Nested Exception classes:
        class GradeTooHighException : public std::exception 
        {
            public:
                virtual const char  *what(void) const throw(); 
        };
        class GradeTooLowException : public std::exception
        {
            public:
                virtual const char *what(void) const throw();
        };

		// ex01
		void signForm(AForm &);

		// ex02
		void executeForm(AForm const &);

	private:
		std::string	_name;
		int			_grade; //1 = highest, 150 = lowest

};

// << overload
std::ostream& operator<<(std::ostream &, const Bureaucrat &);


#endif