/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Intern.hpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ekocak@student.42.org.tr>                  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/05 01:32:55 by ekocak            #+#    #+#             */
/*   Updated: 2023/08/05 01:32:55 by ekocak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "PresidentialPardonForm.hpp"
#include "RobotomyRequestForm.hpp"
#include "ShrubberyCreationForm.hpp"

#define DEBUG_INTERN    1 

class Intern
{
    private:
    private:
        AForm* _generatePresidentialPardonForm(std::string const& target);
        AForm* _generateRobotomyRequestForm(std::string const& target);
        AForm* _generateShrubberyCreationForm(std::string const& target);
    public:
        //Constructors and Destructors
        Intern();
        ~Intern();
        //The pointer returned points to AForm whose name is the first parameter.
        //The target of the returned form will be initialized to the second parameter. 
        AForm *makeForm(std::string, std::string);
        //The try - catch mechanism attempts to execute the code block following the try
        //statement. In case of an error, the code following the catch statement is executed.
        //the catch block states which exception is to be executed in case of an error.
        //Once the exception code is execution is completed, the program continues onto
        //execute beyond the try-catch mechanism. 
        class UnrecognisableFormNameException : public std::exception
        {
            public:
                virtual const char *what() const throw();
        };
};


/*
class Intern
{
public:
    //Constructors and Destructors
    Intern();
    ~Intern();
    //The pointer returned points to AForm whose name is the first parameter.
    //The target of the returned form will be initialized to the second parameter.
    
    AForm *makeForm(std::string formName, std::string formTarget);

private:
    typedef AForm *(*FormConstructor)(std::string);
    static const int numForms = 3;
    std::string formNames[numForms];
    FormConstructor formConstructors[numForms];
}; */